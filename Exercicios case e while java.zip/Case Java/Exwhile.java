import java.util.Scanner;

public class Exwhile{
    public static void main(String[] args) {
        Scanner sequencia = new Scanner(System.in);
        System.out.println("Entre com o valor inicial: ");
        int inicial = sequencia.nextInt();
        System.out.println("Entre com o valor final: ");
        int fim = sequencia.nextInt();
        System.out.println("");
        if (inicial < fim){
        while (inicial <= fim) {
            System.out.println(inicial);
            inicial++;
        }
    } if (inicial > fim){
        while (inicial >= fim) {
            System.out.println(inicial);
            inicial--;
        }
    }
        sequencia.close();
    }
}